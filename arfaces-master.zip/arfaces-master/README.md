# Augmented Faces ARCore tutorials
Augmented Faces for Android

<b> Try-On makeup with Augmented Faces </b> <br/>
Blog post -> https://creativetech.blog/home/augmented-faces-makeup
<br/>
<br/>
<b> Try-On glasses with Augmented Faces </b> <br/>
Blog post -> https://creativetech.blog/home/try-on-glasses-arcore-augmented-faces
<br/>
<br/>
<b> Instagram - like filter "Which ... are you?" with Augmented Faces </b> <br/>
Blog post -> https://creativetech.blog/home/which-are-you-instagram-like-filter-arcore
<br/>
<br/>
<b> Face Landmarks for ARCore Augmented Faces </b> <br/>
Blog post -> https://creativetech.blog/home/face-landmarks-for-arcore-augmented-faces

# Augmented Faces WITHOUT Sceneform
<b> Check out ARCore.How -> https://arcore.how </b> </br>
Blog post -> https://creativetech.blog/home/augmented-faces-without-sceneform 
<br>
