## Covid-19 Sahayak

![GitHub followers](https://img.shields.io/github/followers/smv1999?style=for-the-badge)
![GitHub forks](https://img.shields.io/github/forks/smv1999/Covid19Sahayak?style=for-the-badge)
![GitHub Repo stars](https://img.shields.io/github/stars/smv1999/Covid19Sahayak?style=for-the-badge)
![Lines of code](https://img.shields.io/tokei/lines/github/smv1999/Covid19Sahayak?style=for-the-badge)

![Covid19Sahayak](https://socialify.git.ci/smv1999/Covid19Sahayak/image?forks=1&issues=1&language=1&owner=1&pattern=Brick%20Wall&pulls=1&stargazers=1&theme=Dark)

### Introduction and Features💡:

This is an android application that provides state level and world level updates on Covid-19. Some amazing features of the app includes:

* Provides complete information about the virus
* Self assessing module
* Live updates at the state and world level
* Prevention and precautionary measures.
* Latest News
* Funds and Helpline
* Essentials and Maps; giving details about the medical stores and hospitals nearby
* Enjoy the app in Dark mode !
